Tracker:AddItems("items/items.json")

Tracker:AddMaps("maps/maps.json")

Tracker:AddLocations("locations/goldentemple.json")
Tracker:AddLocations("locations/hydrostation.json")
Tracker:AddLocations("locations/industrialcomplex.json")
Tracker:AddLocations("locations/thetower.json")
Tracker:AddLocations("locations/distributioncenter.json")
Tracker:AddLocations("locations/sr388.json")

Tracker:AddLayouts("tracker_layout.json")
Tracker:AddLayouts("broadcast_layout.json")
