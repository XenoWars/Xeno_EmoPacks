
Tracker:AddMaps("maps.json")
Tracker:AddLocations("locations/templegrounds.json")
Tracker:AddLocations("locations/skytemplegrounds.json")
Tracker:AddLocations("locations/agonwastes.json")
Tracker:AddLocations("locations/darkagon.json")
Tracker:AddLocations("locations/torvusbog.json")
Tracker:AddLocations("locations/darktorvus.json")
Tracker:AddLocations("locations/sanctuaryfortress.json")
Tracker:AddLocations("locations/inghive.json")
Tracker:AddLocations("locations/greattemple.json")


Tracker:AddLayouts("tracker_layout.json")
Tracker:AddLayouts("broadcast_layout.json")